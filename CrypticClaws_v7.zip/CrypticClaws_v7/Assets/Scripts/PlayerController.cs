using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] bool isWalking;
    [SerializeField] float walkSpeed;
    [SerializeField] float runSpeed;


    [SerializeField] bool isGrounded;//says whether the player is touching the ground or not
    
    [SerializeField] bool isHoldingItemRight; //if the right hand is holding anything in it, we can convert this later if we need to
    [SerializeField] List<GameObject> itemsToHold = new List<GameObject>();

    private CharacterController characterController;//lets us use the character controller thats attached to the player

    [SerializeField] float rotationX = 0f;
    [SerializeField] float rotationY = 0f;

    public float mouseSens = 5f;

    // Start is called before the first frame update
    void Start()
    {
        characterController = GetComponent<CharacterController>();
        isHoldingItemRight = false;
        isWalking = false;
    }

    // Update is called once per frame
    void Update()
    {
        Movement();
        OnEButtonDown();
    }

    void Movement()
    {
        // Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        // characterController.Move(move*Time.deltaTime*walkSpeed);

        //camera movement
        rotationY += Input.GetAxis("Mouse X") * mouseSens;
        rotationX += Input.GetAxis("Mouse Y") * -1 * mouseSens;
        transform.localEulerAngles = new Vector3(rotationX, rotationY, 0);

        if (Input.GetKey(KeyCode.W))
        {
            isWalking = true;
            transform.position += transform.forward * Time.deltaTime * walkSpeed;
            isWalking = false;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            isWalking = true;
            transform.position -= transform.forward * Time.deltaTime * walkSpeed;
            isWalking = false;
        }
        else if (Input.GetKey(KeyCode.A))
        {
            isWalking = true;
            transform.position -= transform.right * Time.deltaTime * walkSpeed;
            isWalking = false;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            isWalking = true;
            transform.position += transform.right * Time.deltaTime * walkSpeed;
            isWalking = false;
        }

        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
          //  characterController.Move(move * Time.deltaTime * runSpeed);
            Debug.Log("is running");
        }

        if (!isWalking)
        {
            transform.position = transform.position;
        }

    }


    private void OnCollisionEnter(Collision collision) // we can use this for anything that the player has to collide with
    {
        if(collision.gameObject.tag == "Ground")
        {
            isGrounded = true;
        }
    }

    private void OnEButtonDown()//controls what we do with the item in the hand
    {
        if (Input.GetKeyDown(KeyCode.E) && isHoldingItemRight == true)
        {
            
        }
    }
}
