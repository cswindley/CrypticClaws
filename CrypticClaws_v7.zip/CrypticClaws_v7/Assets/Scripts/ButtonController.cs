using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour
{
    public void OnApplicationQuit()
    {
        Application.Quit();
    }

    public void OnMenuButtonClick()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void OnCreditsButtonClick()
    {
        SceneManager.LoadScene("CreditsMenu");
    }

    public void OnHelpButtonClick()
    {
        SceneManager.LoadScene("HelpMenu");
    }

    public void OnLevelOneButtonClick()
    {
        SceneManager.LoadScene("Level1");
    }
}
