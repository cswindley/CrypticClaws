using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyV4 : MonoBehaviour
{
    #region AI
    enum AIState { wandering, stalking, investigatingPlayer, investigatingItem, attacking};
    private AIState currentState;
    public bool isBusy;

    public UnityEngine.AI.NavMeshAgent navAgent;
    public Transform playerPos;

#endregion
}
