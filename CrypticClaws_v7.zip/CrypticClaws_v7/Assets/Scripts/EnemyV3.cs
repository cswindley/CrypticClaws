using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Random = UnityEngine.Random;

/*
 * I wanteed to try to make my own version just to understand everything and see if I can fix it/clean it
 * up here :) I'm also gonna note any changes I make just so that we know in case it breaks too
 * 
 * Added wandering state to be a sort of default state/more for testing than an actual state
 * 
 * Got rid of things we aren't using yet, like the noise level just for right now
 * 
 * We can add an isDistracted bool to take place of the investigatingItem if we need to, but we'll see
 * Added isBusy bool
 */
public class EnemyV3 : MonoBehaviour
{
    //class variables

    #region AI
    //ai mess
    enum AIState { stalking, investigatingPlayer, investigatingItem, attacking, wandering};
    private AIState currentState;
    public bool isBusy;

    public NavMeshAgent navAgent;
    public Transform playerPos;
    public LayerMask groundMask, playerMask;

    private Vector3 walkPoint;
    private bool walkPointSet = false;
    //private float walkPointRange = 30;
    private float walkpointAngleRange = 45; // 45 degrees in both directions, meaning it can move anywhere within the 90 degrees around it

    //[SerializeField] private bool busy = false; I think this is solved with the AI states
    #endregion

    #region Speeds and Materials
    //Speeds and Materials
    private float stalkingSpeed = 4;
    private float investigatingSpeed = 6;
    private float attackingSpeed = 8;
    private float wanderingSpeed = 5;

    public Material stalkingMaterial;
    public Material investigatingPlayerMaterial;
    public Material investigatingItemMaterial;
    public Material attackingMaterial;
    public Material wanderingMaterial;
    #endregion

    #region States
    //variables for states - I may change what isn't needed with the state controller
    private float sightRange = 25, attackRange = 10;
    private bool playerInSightRange, playerInAttackRange;
    private bool noisyInSightRange;


    //stalking
    private float minStalkingDistance = 25;
    private float maxStalkingDistance = 50;
    private const float TimeBetweenStalking = 3;
    private float timeBeforeNextStalk = 0;


    //investigating
    private const float InvestigatingTime = 6;
    private float timeLeftToInvestigate = 0;
    private bool investigating = false;
    private Transform investingatingPos;


    //attacking
    private const float atkCooldown = 15;
    private float atkCooldownTime = 0;
    private int aggression = 1; //aggression increases based on sound, up to 10. changes how much it tries to attack
    private bool attacking = false;    //attacking the player
    private bool atkConnected = false; //investigating sound
    #endregion

    //methods

    private void Awake()
    {
        playerPos = GameObject.Find("Player").transform;
        navAgent = GetComponent<NavMeshAgent>();
        currentState = AIState.wandering;
        isBusy = false;
    }

    private void Update()
    {
        if(!isBusy) 
        {
            Ranges();
            DetermineStates();
        }
        
        HandleStates();
    }

    IEnumerator BusyTimer(int coolDownTime)
    {
        for(int i = 0; i < coolDownTime; i++)//cooldown timer needs to go for i here
        {
            isBusy = true;
            yield return new WaitForSeconds(1);
        }
        isBusy = false;
    }

    private void Ranges()
    {
        playerInSightRange = Physics.CheckSphere(transform.position, sightRange, playerMask);
        playerInAttackRange = Physics.CheckSphere(transform.position, attackRange, playerMask);
    }

    private void DetermineStates()
    {
        //Ranges() may need to go here instead, but we'll see

        if ()//stalking first
        {
            currentState = AIState.stalking;
        }
        else if() //investigating the player
        {
            currentState = AIState.investigatingPlayer;
        }
        else if () //investigating the item the player threw
        {
            currentState = AIState.investigatingItem;
        }
        else if () //attacking the player
        {
            currentState = AIState.attacking;
        }
        else //basically doing nothing
        {
            currentState = AIState.wandering;
        }
    }

    private void HandleStates()//needs to include where the enemy goes from here
    {
        switch(currentState)
        {
            case AIState.stalking:
                if (!walkPointSet)
                {
                    SearchWalkPoint();
                }
                if (walkPointSet)
                {
                    navAgent.SetDestination(walkPoint);
                }
                Vector3 distanceToWalkPoint = transform.position - walkPoint;
                if(distanceToWalkPoint.magnitude <= 2f)
                {
                    Debug.Log("reached stalking walkpoint");
                    timeBeforeNextStalk = TimeBetweenStalking;
                    walkPointSet = false;
                }
                GetComponent<Renderer>().material = stalkingMaterial;
                navAgent.speed = stalkingSpeed;
                Debug.Log("stalking");
                break;

            case AIState.investigatingPlayer:
                GetComponent<Renderer>().material = investigatingPlayerMaterial;
                navAgent.speed = investigatingSpeed;
                Debug.Log("investigating player");
                break;

            case AIState.investigatingItem:
                GetComponent<Renderer>().material = investigatingItemMaterial;
                navAgent.speed = investigatingSpeed;
                Debug.Log("investigating item");
                break;

            case AIState.attacking:
                GetComponent<Renderer>().material = attackingMaterial;
                navAgent.speed = attackingSpeed;
                Debug.Log("attacking");
                break;

            case AIState.wandering:
                GetComponent<Renderer>().material = wanderingMaterial;
                navAgent.speed = wanderingSpeed;
                Debug.Log("wandering");
                break;

            default:
                Debug.Log("unknown state");
                break;
        }
    }

    private void SearchWalkPoint()
    {
        //generate angle between -walkpoint angle and +walkpoint angle
        float randAngle = Random.Range(-walkpointAngleRange, walkpointAngleRange);

        //generate some distance between minstalk and maxstalk
        float randomArea = Random.Range(minStalkingDistance - aggression, maxStalkingDistance);

        //set walkpoint via angle and distance
        Vector3 direction = (transform.position - playerPos.position).normalized;
        Vector3 tempWalkPoint = direction * randomArea;
        walkPoint = playerPos.position + (Quaternion.Euler(0, randAngle, 0) * tempWalkPoint);

        //walk point = playerpos + (random rotation * arealength)
        //walkPoint = (playerPos.position + (rotation * (Vector3.forward *randomArea)));

        Vector3 walkpointDistanceToPlayer = walkPoint - playerPos.position;

        if (walkpointDistanceToPlayer.magnitude > maxStalkingDistance)
        {
            print("walkpoint outside max stalking range");
            walkPoint = playerPos.position + (walkPoint - playerPos.position).normalized * maxStalkingDistance;
        }
        if (walkpointDistanceToPlayer.magnitude < minStalkingDistance)
        {
            print("walkpoint outside min stalking range");
            walkPoint = playerPos.position + (walkPoint - playerPos.position).normalized * minStalkingDistance;
        }

        if (Physics.Raycast(walkPoint, -transform.up, 3f, groundMask))
        {
            walkPointSet = true;
        }
    }
}
