using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

/*
 * 
 * 
 */


public class EnemyV4 : MonoBehaviour
{
    public int enemyAggro;
    public int movementOppCooldown;
    public PlayerHealth playerHealth;// from the player health script
    
    #region AI
    enum AIState { investigating, stalking, attacking, busy};
    private AIState currentState;
    public bool isBusy;
    private float timeBeforeAction;
    private float actionTimeLength;

    public UnityEngine.AI.NavMeshAgent navAgent;
    [SerializeField] private GameObject player;//assigned in the inspector, done this way so that we can use Distance function
    public float playerDist;

    [SerializeField] private bool isReadyToMove;
    #endregion

    #region Speeds and materials
    private float stalkingSpeed = 4;
    private float investigatingSpeed = 5;
    private float attackingSpeed = 8;
    private float busySpeed = 1;

    [SerializeField] private Material stalkingMaterial;
    [SerializeField] private Material investigatingMaterial;
    [SerializeField] private Material attackingMaterial;
    [SerializeField] private Material busyMaterial;
    #endregion

    #region Important locations
    //outside big circle is stalking, between the circles is investigating, and inside small is attacking
    private float playerBigCircle = 50;
    private float playerSmallCircle = 30;

    [SerializeField] Vector3 toGo;
    #endregion

    private void Awake()
    {
        playerDist = Vector3.Distance(transform.position, player.transform.position);
        enemyAggro = 2;//just rn for testing
        isReadyToMove = true;
    }

    private void Update()
    {
        DetermineStates();
        HandleStates();
    }

    private IEnumerator MovementOpWait()//movement op timer
    {
        Debug.Log("started at time:" + Time.time);
        yield return new WaitForSeconds(movementOppCooldown);
        Debug.Log("ended at time:" + Time.time);
    }

    private IEnumerator TimerWait(int timer)
    {
        yield return new WaitForSeconds(timer);
    }

    private Vector3 FindPlaceToGoInvestigate()
    {
        float closeToCurrentX = transform.position.x - UnityEngine.Random.Range(-30,30);
        float closeToCurrentZ = transform.position.z - UnityEngine.Random.Range(-30,30);

        //float randXInRange = UnityEngine.Random.Range(playerDist + 10, playerDist + 10);
        //float randZInRange = UnityEngine.Random.Range(playerDist + 10, playerDist + 10);

        toGo.x = closeToCurrentX;
        toGo.z = closeToCurrentZ;
        return toGo;
    }

    private void DetermineStates()
    {
        playerDist = Vector3.Distance(transform.position, player.transform.position);

        if (isBusy)//enemy is busy
        {
            currentState = AIState.busy;
        }
        else if(playerDist < 10)//player gets too close
        {
            currentState = AIState.attacking;
            //DoesDamage();//damages the player
            //Debug.Log("doing 1 damage");
        }
        else if(playerDist < playerSmallCircle && enemyAggro >= 4)//player gets closeish and its not happy anyway
        {
            currentState = AIState.attacking;
            //DoesDamage();//damages the player
            //Debug.Log("doing 1 damage");
        }
        else if(playerDist <= playerBigCircle)//its not particularly close to the player vise versa
        {
            currentState= AIState.investigating;
        }
        else//the player is far away from the enemy
        {
            currentState = AIState.stalking;
        }
    }

    private void HandleStates()
    {
        movementOppCooldown = 10 - enemyAggro;
        //for ex: agg of 4 would mean cooldown is 6 seconds, agg of 8 would mean 2 second cooldown

        if (timeBeforeAction > 0)
        {
            timeBeforeAction -= Time.deltaTime;
        }

        if(actionTimeLength > 0) 
        {
            actionTimeLength -= Time.deltaTime;
        }

        if (timeBeforeAction <= 0)
        {
            switch (currentState)
            {
                case AIState.stalking:

                    Stalking();
                    timeBeforeAction = 6;
                    actionTimeLength = 2;
                    break;

                case AIState.investigating://where the movement op happens
                    
                    Investigating();
                    timeBeforeAction = movementOppCooldown;
                    actionTimeLength = 2;
                    break;

                case AIState.attacking:
                    GetComponent<Renderer>().material = attackingMaterial;
                    navAgent.SetDestination(player.transform.position);
                    navAgent.speed = attackingSpeed;
                    if(playerDist < 5)
                    {
                        DoesDamage();
                        Debug.Log("Doing 1 damage");
                    }
                    break;

                case AIState.busy://location of thrown items will go here
                    GetComponent<Renderer>().material = busyMaterial;
                    StartCoroutine(TimerWait(3));//waits for 3 seconds if busy
                    navAgent.speed = busySpeed;
                    break;

                default:
                    Debug.Log("no state determined");
                    break;
            }
        }

    }
   
/*
    private IEnumerator StalkingState()
    {
        GetComponent<Renderer>().material = stalkingMaterial;
        navAgent.speed = stalkingSpeed;
        yield return new WaitForSeconds(10);
    }

    private IEnumerator InvestigatingState()
    {
        
        yield return new WaitForSeconds(3);
        GetComponent<Renderer>().material = investigatingMaterial;
        navAgent.speed = investigatingSpeed;
        FindPlaceToGoInvestigate();
        navAgent.SetDestination(toGo);

    }
*/
    private void Stalking()
    {
        GetComponent<Renderer>().material = stalkingMaterial;
        navAgent.speed = stalkingSpeed;
        navAgent.SetDestination(player.transform.position);
    }

    private void Investigating()
    {
        GetComponent<Renderer>().material = investigatingMaterial;
        navAgent.speed = investigatingSpeed;
        FindPlaceToGoInvestigate();
        navAgent.SetDestination(toGo);
    }

    private void DoesDamage() // does damage to the player from the other script
    {
        playerHealth.PlayerHurt();
        StartCoroutine(TimerWait(5));
    }
}
