using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Random = UnityEngine.Random;

/*
A couple of quick notes I wanted to go over today, it may be a better idea to handle
switching states with switch code and not if statements, I think the if statements are a bit
too much for it to handle all in one area, we can separate this out into a Determine State and a Handle State methods, 
Determine state would have all your information about what state the enemy needs to be in, and Handle states will control
how those actually work, I think right now its getting a bit confused about the state but I need to test it some more
to make sure what I'm thinking is right

if theres ever a point where we dont want the enemy to be stalking the player we can use point indexes, but we dont need to touch
those unless we think we're actually going to have the enemy be doing anything else besides be all up on the player


everyone shut up i found the main issue I'm still gonna try to clean everything up but I found the 
issue, you never tell it how to determine the states i think, I'm trying to figure out how it knows
to attack but can't seem to find it,

jk everyone I found it but I think the issue is that its given the ability to assign the state after
its checking to see the state so I think its just confused there

also I think we need to separate the investigating state into investigatingPlayer and investigatingObject
*/
public class EnemyV2Script : MonoBehaviour
{
    //ai input info
    public NavMeshAgent navAgent;
    public Transform playerPos;
    public LayerMask groundMask, playerMask;
    private int playerNoiseLevel;
    private Transform noiseToInvestigatePos;

    //things carley added 8/22/2023:
    //ai:
    enum AIState { stalking, investigating, attacking};
    private AIState currentState;

    //ai stats
    private Vector3 walkPoint;
    private bool walkPointSet = false;
    //private float walkPointRange = 30;
    private float walkpointAngleRange = 45; // 45 degrees in both directions, meaning it can move anywhere within the 90 degrees around it

    [SerializeField] private bool busy = false; //used to keep enemy acting on one action at a time

    private float stalkingSpeed = 4;
    private float investigatingSpeed = 6;
    private float attackingSpeed = 8;

    public Material stalkingMaterial;
    public Material investigatingMaterial;
    public Material attackingMaterial;

    //states
    private float sightRange = 25, attackRange = 10;
    private bool playerInSightRange, playerInAttackRange;
    private bool noisyInSightRange;


    //stalking
    private float minStalkingDistance = 25;
    private float maxStalkingDistance = 50;
    private const float TimeBetweenStalking = 3;
    private float timeBeforeNextStalk = 0;


    //investigating
    private const float InvestigatingTime = 6;
    private float timeLeftToInvestigate = 0;
    private bool investigating = false;
    private Transform investingatingPos;


    //attacking
    private const float atkCooldown = 15;
    private float atkCooldownTime = 0;
    private int aggression = 1; //aggression increases based on sound, up to 10. changes how much it tries to attack
    private bool attacking = false;    //attacking the player
    private bool atkConnected = false; //investigating sound


    private void Awake()
    {
        playerPos = GameObject.Find("Player").transform;
        navAgent = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        StateController();
    }

    private void StateController()
    {
        if (noiseToInvestigatePos)//not currently being used bc it isn't implemented yet
        {
            noisyInSightRange = Physics.CheckSphere(transform.position, sightRange);
        }
        else
        {
            noisyInSightRange = false;
        }
        playerInSightRange = Physics.CheckSphere(transform.position, sightRange, playerMask);
        playerInAttackRange = Physics.CheckSphere(transform.position, attackRange, playerMask);

        if (attacking)
        {
            if (atkCooldownTime <= 0)
            {
                Attacking();
                Debug.Log("attacking");
                return;
            }
        }
        if (investigating)
        {
            if (timeLeftToInvestigate <= 0)
            {
                Investigating();
                Debug.Log("investigating");
                return;
            }
        }

        //chance to attack based on aggression
        if (playerInAttackRange)
        {
            float chanceToAttack = Random.value;
            if (chanceToAttack <= aggression / (10 - aggression))
            {
                attacking = true;
                busy = true;
                return;
            }
        }

        //gives chance to attack before blocking onto other actions via busy)
        if (busy)
        {
            return;
        }

        //investigate player based on aggression and sound level
        if (playerInSightRange && !noisyInSightRange && !playerInAttackRange)
        {
            float chanceToInvestigate = Random.value;
            if (chanceToInvestigate <= aggression / (10 - playerNoiseLevel))
            {
                currentState = AIState.investigating;
                //carley added above this line
                investigating = true;
                investingatingPos = playerPos;
                busy = true;
                Investigating();
                return;
            }
        }

        //if sound is made by object within radius, investigate
        if (noisyInSightRange && !playerInSightRange && !playerInAttackRange)
        {
            currentState = AIState.investigating;
            //carley added above this line
            investigating = true;
            investingatingPos = noiseToInvestigatePos;
            busy = true;
            Investigating();
            return;
        }

        //if noisyObject and player in radius, check to see which to investigate
        if (noisyInSightRange && playerInSightRange && !playerInAttackRange)
        {
            float chanceToInvestigate = Random.value;
            if (chanceToInvestigate <= aggression / (10 - playerNoiseLevel))
            {
                investingatingPos = playerPos;
            }
            else
            {
                investingatingPos = noiseToInvestigatePos;
            }
            investigating = true;
            busy = true;
            Investigating();
            return;
        }

        //stalk by default
        if (!noisyInSightRange && !playerInSightRange && !playerInAttackRange)
        {
            if (timeBeforeNextStalk <= 0)
            {
                Stalking();
            }
        }

        if (timeBeforeNextStalk > 0)
        {
            timeBeforeNextStalk -= Time.deltaTime;
        }
        if (timeLeftToInvestigate > 0)
        {
            timeLeftToInvestigate -= Time.deltaTime;
        }
    }

    private void Stalking()
    {
        print("stalking");
        navAgent.speed = stalkingSpeed;
        gameObject.GetComponent<Renderer>().material = stalkingMaterial;

        if (!walkPointSet) { SearchWalkPoint(); }

        if (walkPointSet) { navAgent.SetDestination(walkPoint); }

        Vector3 distanceToWalkPoint = transform.position - walkPoint;

        //walkpoint reached
        if (distanceToWalkPoint.magnitude <= 2f)
        {
            print("reached stalking walkpoint");
            timeBeforeNextStalk = TimeBetweenStalking;
            walkPointSet = false;
            //Invoke("NoLongerBusy", TimeBetweenStalking);
        }
    }

    private void Investigating()
    {
        print("investigating");
        navAgent.speed = investigatingSpeed;
        gameObject.GetComponent<Renderer>().material = investigatingMaterial;
        walkPoint = investingatingPos.position;
        navAgent.SetDestination(walkPoint);

        Vector3 distanceToWalkPoint = transform.position - walkPoint;
        if (distanceToWalkPoint.magnitude <= 2f)
        {
            print("reached investigation walkpoint");
            timeLeftToInvestigate = InvestigatingTime;
            walkPointSet = false;
            investigating = false;
        }
    }

    private void Attacking()
    {
        print("attacking");
        navAgent.speed = attackingSpeed;
        gameObject.GetComponent<Renderer>().material = attackingMaterial;
    }

    private void NoLongerBusy()
    {
        print("noLongerBusy");
        busy = false;
    }

    private void ReturnToStalking()
    {

    }

    private void SearchWalkPoint()
    {
        //generate angle between -walkpoint angle and +walkpoint angle
        float randAngle = Random.Range(-walkpointAngleRange, walkpointAngleRange);
        //generate some distance between minstalk and maxstalk
        float randomArea = Random.Range(minStalkingDistance - aggression, maxStalkingDistance);
        //set walkpoint via angle and distance
        Vector3 direction = (transform.position - playerPos.position).normalized;
        Vector3 tempWalkPoint = direction * randomArea;
        walkPoint = playerPos.position + (Quaternion.Euler(0, randAngle, 0) * tempWalkPoint);

        //walk point = playerpos + (random rotation * arealength)
        //walkPoint = (playerPos.position + (rotation * (Vector3.forward *randomArea)));

        Vector3 walkpointDistanceToPlayer = walkPoint - playerPos.position;

        if (walkpointDistanceToPlayer.magnitude > maxStalkingDistance)
        {
            print("walkpoint outside max stalking range");
            walkPoint = playerPos.position + (walkPoint - playerPos.position).normalized * maxStalkingDistance;
        }
        if (walkpointDistanceToPlayer.magnitude < minStalkingDistance)
        {
            print("walkpoint outside min stalking range");
            walkPoint = playerPos.position + (walkPoint - playerPos.position).normalized * minStalkingDistance;
        }

        if (Physics.Raycast(walkPoint, -transform.up, 3f, groundMask))
        {
            walkPointSet = true;
        }
    }

    private void StompHandler()
    {
        //play sound

        //play particles at position on ground
    }

    private void DealDamage()
    {
        //deal damage to player

        //return to stalking/ teleport to edge of stalking radius
    }

    private void GetPlayerNoise()
    {
        //call function in player to get noise value
        //playerNoiseLevel = player.GetNoiseLevel();
    }

    //whenever distraction objects land, call this to "make noise"
    public void SetNoisyObject(Transform objectPos)
    {
        noiseToInvestigatePos = objectPos;
    }

    public void SetAggression(int aggro)
    {
        aggression = aggro;
    }
}
