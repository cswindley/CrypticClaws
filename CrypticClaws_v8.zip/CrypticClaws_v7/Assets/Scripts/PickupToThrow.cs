using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class PickupToThrow : MonoBehaviour
{
    [SerializeField] float throwForce = 600;
    private Vector3 objectPos;
    private float distance;

    public bool canHold = true;
    public List<GameObject> itemsToThrow = new List<GameObject>();
    public List<GameObject> flareToThrow = new List<GameObject>();
    public List<GameObject> flashlightHold = new List<GameObject>();
    public GameObject tempParent;
    public GameObject tempParent2;
    public GameObject tempParent3;
    public GameObject hiddenInvLocation;
    public GameObject shownInvLocation;
    public bool isHoldingThrow = false;

    // Start is called before the first frame update
    void Start()
    {
        throwForce = 2000;
    }

    // Update is called once per frame
    void Update()
    {
        OnFButtonDown();
        OnEButtonDown(itemsToThrow, tempParent, shownInvLocation);
        OnEButtonDown(flareToThrow, tempParent2, shownInvLocation);
        OnInvButtonDown();
    }
    
    private void OnFButtonDown()//responsible for picking up the item and adding it to a list
    {
        RaycastHit hit;

        if (Input.GetKeyDown(KeyCode.F))
        {
            if (Physics.Raycast(transform.position, transform.forward, out hit, 100f))//60 is the distance from the player that they can grab an object
            {
                if(hit.collider.gameObject.tag == "Pickup")//this happens if they try to pickup like a rock to throw
                {
                    itemsToThrow.Add(hit.collider.gameObject);
                    distance = Vector3.Distance(itemsToThrow[0].transform.position, tempParent.transform.position);
                    itemsToThrow[0].GetComponent<Rigidbody>().useGravity = false;
                    itemsToThrow[0].GetComponent<Rigidbody>().detectCollisions = false;
                    itemsToThrow[0].transform.SetParent(tempParent.transform);
                    itemsToThrow[0].transform.position = tempParent.transform.position;
                    itemsToThrow[0].isStatic = true;
                    itemsToThrow[0].GetComponent<Rigidbody>().isKinematic = true;
                    
                    isHoldingThrow = true;

                    if (distance >= 20f)//if they're far away the item drops
                    {
                        isHoldingThrow = false;
                    }          
                }

                if(hit.collider.gameObject.tag == "Flare")//this would be a flare
                {
                    flareToThrow.Add(hit.collider.gameObject);
                    distance = Vector3.Distance(flareToThrow[0].transform.position, tempParent.transform.position);
                    flareToThrow[0].GetComponent <Rigidbody>().useGravity = false;
                    flareToThrow[0].GetComponent<Rigidbody>().detectCollisions=false;
                    flareToThrow[0].transform.SetParent(tempParent2.transform);
                    flareToThrow[0].transform.position = tempParent2.transform.position;
                    flareToThrow[0].isStatic=true;
                    flareToThrow[0].GetComponent<Rigidbody>().isKinematic=true;
                    isHoldingThrow = true;
                }

                if(hit.collider.gameObject.tag == "Flashlight")//and this is for a flashlight
                {
                    flashlightHold.Add(hit.collider.gameObject);
                    flashlightHold[0].GetComponent<Rigidbody>().useGravity=false;
                    flashlightHold[0].GetComponent<Rigidbody>().detectCollisions =false;
                    flashlightHold[0].transform.SetParent(tempParent3.transform);
                    flashlightHold[0].transform.position =tempParent3.transform.position;
                    flashlightHold[0].isStatic=true;
                    flashlightHold[0].GetComponent<Rigidbody>().isKinematic=true;
                }

                Debug.Log("is holding throw is " + isHoldingThrow);
                Debug.Log("raycast was sent");
                Debug.Log(hit.collider.gameObject.name);
            }

        }
    }

    private void OnEButtonDown(List<GameObject> throwItemType, GameObject parentTemp, GameObject frontInventorySlot)//responsible for throwing an item if its able to be thrown
    {
        if(throwItemType.Count <= 0) 
        {
            return;
        }
        else// if (isHoldingThrow)
        {
            if (throwItemType[0].transform.position == frontInventorySlot.transform.position)//if its the one being held, it can be thrown
            {
                if (Input.GetKeyDown(KeyCode.E))
                {
                    throwItemType[0].GetComponent<Rigidbody>().useGravity = true;
                    throwItemType[0].GetComponent<Rigidbody>().isKinematic = false;
                    throwItemType[0].GetComponent<Rigidbody>().velocity = Vector3.zero;
                    throwItemType[0].GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
                    throwItemType[0].GetComponent<Rigidbody>().detectCollisions = true;
                    throwItemType[0].GetComponent<Rigidbody>().AddForce(parentTemp.transform.forward * throwForce);
                    objectPos = throwItemType[0].transform.position;
                    throwItemType[0].transform.SetParent(null);

                    throwItemType[0].transform.position = objectPos;
                    throwItemType.RemoveAt(0);
                    isHoldingThrow = false;
                }
            }
        }
    }

    private void OnInvButtonDown()//Handles the inventory slots using 1,2,3 for rock, flare, flashlight
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            tempParent.transform.position = shownInvLocation.transform.position;
            tempParent2.transform.position = hiddenInvLocation.transform.position;
            tempParent3.transform.position = hiddenInvLocation.transform.position;           
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            tempParent2.transform.position = shownInvLocation.transform.position;
            tempParent.transform.position = hiddenInvLocation.transform.position;
            tempParent3.transform.position= hiddenInvLocation.transform.position;
        }

        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            tempParent3.transform.position = shownInvLocation.transform.position;
            tempParent.transform.position= hiddenInvLocation.transform.position;
            tempParent2.transform.position=hiddenInvLocation.transform.position;
        }
    }
}
