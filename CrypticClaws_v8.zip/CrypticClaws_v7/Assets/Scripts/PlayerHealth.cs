using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;

public class PlayerHealth : MonoBehaviour
{
    public float health;
    public TMP_Text healthText;
    [SerializeField] private GameObject lossPanel;

    // Start is called before the first frame update
    void Start()
    {
        healthText.text = "player health is " + health;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PlayerHurt()
    {
        health -= 1;
        if (health <= 0)
        {
            lossPanel.SetActive(true);
        }
    }
}
