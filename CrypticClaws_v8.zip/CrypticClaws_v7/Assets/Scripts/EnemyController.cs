using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using Random = UnityEngine.Random;

public class EnemyController : MonoBehaviour
{

    public Material stalkingMaterial;
    public Material investigatingMaterial;
    public Material attackingMaterial;
    //ai info
    public NavMeshAgent navAgent;
    public Transform playerPos;
    public Transform noiseToInvestigatePos;
    public LayerMask groundMask, playerMask;

    //patrolling
    public Vector3 walkPoint;
    bool walkPointSet = false;
    public const float TimeBetweenStalking = 3;
    public float timeBeforeNextStalk = 0;
    public float walkPointRange = 30;
    public float stalkingSpeed = 4;
    public float investigatingSpeed = 6;
    public float chargingSpeed = 8;
    public float investigatingTime = 5;
    public float minStalkingDistance = 25;
    public float maxStalkingDistance = 50;
    //[SerializeField] private bool investigating = false; //investigating sound

    //attacking
    public float atkCooldown = 15;
    [SerializeField] private int aggression = 0; //aggression increases based on sound, up to 10. changes how much it tries to attack
    [SerializeField] private bool attacking = false;    //attacking the player
    [SerializeField] private bool attackConnected = false; //investigating sound

    //states
    public float sightRange = 20, attackRange = 10;
    public bool playerInSightRange, playerInAttackRange;

    private void Awake()
    {
        playerPos = GameObject.Find("Player").transform;
        navAgent = GetComponent<NavMeshAgent>();
    }

    private void Update()
    {
        //check for sight and attack range    
        playerInSightRange = Physics.CheckSphere(transform.position, sightRange, playerMask);
        playerInAttackRange = Physics.CheckSphere(transform.position, attackRange, playerMask);

        //test for other layers
        bool groundInSightRange = Physics.CheckSphere(transform.position, sightRange, groundMask);
        print("groundmask check: " + groundInSightRange);

        print(playerInSightRange + " " + playerInAttackRange);

        if(!playerInSightRange && !playerInAttackRange)
        {
            if (timeBeforeNextStalk > 0)
            {
                print("WAITING FOR STALKING");
                timeBeforeNextStalk -= Time.deltaTime;
                return;
            }
            navAgent.speed = stalkingSpeed;
            Stalking(); 
        }
        if (playerInSightRange && !playerInAttackRange) 
        {
            navAgent.speed = investigatingSpeed;
            Investigating(); 
        }
        if (playerInSightRange && playerInAttackRange)
        {
            navAgent.speed = chargingSpeed;
            //Attacking(); 
            Charge();
        }
    }

    private void Stalking()
    {
        gameObject.GetComponent<Renderer>().material = stalkingMaterial;
        if (!walkPointSet) { SearchWalkPoint();  }

        if (walkPointSet) { navAgent.SetDestination(walkPoint); }

        Vector3 distanceToWalkPoint = transform.position - walkPoint;

        //walkpoint reached
        if(distanceToWalkPoint.magnitude <= 2f)
        {
            print("reached stalking walkpoint");
            timeBeforeNextStalk = TimeBetweenStalking;
            walkPointSet = false;
        }
    }

    private void SearchWalkPoint()
    {
        //calculate random point in range
        float randomZ = Random.Range(-walkPointRange, walkPointRange);
        float randomX = Random.Range(-walkPointRange, walkPointRange);

        walkPoint = new Vector3(transform.position.x + randomX, transform.position.y, transform.position.z + randomZ);
        //possibly other walkpoint, pick a point within radius of player between min and max stalk
        float randomArea = Random.Range(minStalkingDistance, maxStalkingDistance);
        Quaternion rotation = Random.rotation;

        //walk point = playerpos + (random rotation * arealength)
        //walkPoint = (playerPos.position + (rotation * (Vector3.forward *randomArea)));

        Vector3 walkpointDistanceToPlayer = walkPoint - playerPos.position;

        if(walkpointDistanceToPlayer.magnitude > maxStalkingDistance)
        {
            print("walkpoint outside max stalking range");
            walkPoint = playerPos.position + (walkPoint - playerPos.position).normalized * maxStalkingDistance;
        }
        if(walkpointDistanceToPlayer.magnitude < minStalkingDistance)
        {
            print("walkpoint outside min stalking range");
            walkPoint = playerPos.position + (walkPoint - playerPos.position).normalized * minStalkingDistance;
        }
        //walkPointSet = true;

        if(Physics.Raycast(walkPoint, -transform.up, 3f, groundMask))
        {
            walkPointSet = true;
        }
    }

    private void Investigating()
    {
        gameObject.GetComponent<Renderer>().material = investigatingMaterial;
        //navAgent.SetDestination(playerPos.position); //change this to noise positions once noises are implemented
        //if close enough/ aggro'd enough, charge player
    }

    //this is for running up to the player specifically once investigating is used for sounds
    private void Charge()
    {
        gameObject.GetComponent<Renderer>().material = attackingMaterial;
        //run up to player
        navAgent.SetDestination(playerPos.position);
        transform.LookAt(playerPos);
        //once it gets close enough, attack
    }

    private void Attacking()
    {
        navAgent.SetDestination(transform.position);
        
        //face towards
        //transform.position = Vector3.RotateTowards(transform.forward, playerPos.position, 1, 0.0f);

        //attack
        if (!attackConnected)
        {
            //deal damage and play sounds/ effects


            attackConnected = true;
            Invoke(nameof(ReturnToStalking), atkCooldown);
        }
    }

    //do this once the player has been hit or the monster is scared off
    private void ReturnToStalking()
    {
        attacking = false;
    }
}
